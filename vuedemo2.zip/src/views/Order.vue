<template>
  <order-bill/>
</template>

<script>
import OrderBill from '../components/OrderBill.vue'
export default {
  components: { OrderBill },

}
</script>

<style>

</style>