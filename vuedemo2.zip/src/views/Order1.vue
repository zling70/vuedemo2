<template>
  <order-bill-1/>
</template>

<script>
import OrderBill1 from '../components/OrderBill1'
export default {
  components: { OrderBill1 }
}
</script>

<style>

</style>