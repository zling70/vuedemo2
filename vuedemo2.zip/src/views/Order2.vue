<template>
  <order-bill-2/>
</template>

<script>
import OrderBill2 from '../components/OrderBill2'
export default {
  components: { OrderBill2 },

}
</script>

<style>

</style>